package com.br.ape.entities;

import java.util.Date;

public class Cliente {
	
	public int id;
	public String name;
	public String desc;
	public String pais;
	public String uf;
	public int qntProjetos;
	public String email;
	public String numero;
	public double lucro;
	public String contrato;
	
	public Cliente() {
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getLucro() {
		return this.lucro;
	}
	public void setLucro(double lucro) {
		this.lucro = lucro;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getPais() {
		return pais;
	}
	public void setPais(String pais) {
		this.pais = pais;
	}
	public String getUr() {
		return uf;
	}
	public void setUr(String uf) {
		this.uf = uf;
	}
	public int getQntProjetos() {
		return qntProjetos;
	}
	public void setQntProjetos(int qntProjetos) {
		this.qntProjetos = qntProjetos;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	public String getContrato() {
		return contrato;
	}
	public void setContrato(String contrato) {
		this.contrato = contrato;
	}
	
	
}

package com.br.ape.entities;

public class Site {
	public int id;
	public int idCliente;
	public String nome;
	public String link;
	public String desc;
	public String valor;
	public String mes;
	public String dtInicio;
	public String dtFim;
	public String dtFinalizada;
	public String minutos;
	public String custoPlugin;
	public char tamanho;
	public char dificuldade;
	public int idResp;
	public int idAux;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getIdCliente() {
		return idCliente;
	}
	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getValor() {
		return valor;
	}
	public void setValor(String valor) {
		this.valor = valor;
	}
	public String getMes() {
		return mes;
	}
	public void setMes(String mes) {
		this.mes = mes;
	}
	public String getDtInicio() {
		return dtInicio;
	}
	public void setDtInicio(String dtInicio) {
		this.dtInicio = dtInicio;
	}
	public String getDtFim() {
		return dtFim;
	}
	public void setDtFim(String dtFim) {
		this.dtFim = dtFim;
	}
	public String getDtFinalizada() {
		return dtFinalizada;
	}
	public void setDtFinalizada(String dtFinalizada) {
		this.dtFinalizada = dtFinalizada;
	}
	public String getMinutos() {
		return minutos;
	}
	public void setMinutos(String minutos) {
		this.minutos = minutos;
	}
	public String getCustoPlugin() {
		return custoPlugin;
	}
	public void setCustoPlugin(String custoPlugin) {
		this.custoPlugin = custoPlugin;
	}
	public char getTamanho() {
		return tamanho;
	}
	public void setTamanho(char tamanho) {
		this.tamanho = tamanho;
	}
	public char getDificuldade() {
		return dificuldade;
	}
	public void setDificuldade(char dificuldade) {
		this.dificuldade = dificuldade;
	}
	
}

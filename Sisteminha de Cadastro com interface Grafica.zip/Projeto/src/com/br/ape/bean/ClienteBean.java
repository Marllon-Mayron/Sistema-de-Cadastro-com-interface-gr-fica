package com.br.ape.bean;

import java.util.List;

import com.br.ape.entities.Cliente;
import com.br.ape.sql.ClienteDAO;


public class ClienteBean {

	private ClienteDAO clienteDao = new ClienteDAO();
	public static boolean procurar;
	
	
	
	public boolean criar(Cliente cliente) {
		return clienteDao.createCliente(cliente);
	}
	public void updateListPlayer() {
		//usuarioDao.findAll();
	}
	public String deletar (Integer user) {
		return clienteDao.delete(user);
	}
	public int contar() {
		return clienteDao.contarCliente();
	}
	public List<Cliente> listarTodos(){
		return clienteDao.findAll();
	}
	public List<Cliente> buscar(String p, String tp){
		return clienteDao.buscas(p, tp);
	}
}

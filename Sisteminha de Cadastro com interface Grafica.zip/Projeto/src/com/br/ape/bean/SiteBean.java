package com.br.ape.bean;

import java.util.List;

import com.br.ape.entities.Cliente;
import com.br.ape.entities.Site;
import com.br.ape.sql.ClienteDAO;
import com.br.ape.sql.SiteDAO;


public class SiteBean {

	private SiteDAO siteDao = new SiteDAO();
	public static boolean procurar;
	
	
	
	public boolean criar(Site site) {
		return siteDao.createCliente(site);
	}
	public void updateListPlayer() {
		//usuarioDao.findAll();
	}
	public String deletar (Integer user) {
		return siteDao.delete(user);
	}
	public int contar() {
		return siteDao.contarCliente();
	}
	public List<Cliente> listarTodos(){
		return siteDao.findAll();
	}
	public List<Cliente> buscar(String p, String tp){
		return siteDao.buscas(p, tp);
	}
}

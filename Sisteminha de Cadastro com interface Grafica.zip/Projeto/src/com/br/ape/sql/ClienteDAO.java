package com.br.ape.sql;

import java.awt.Color;
import java.awt.Graphics;
import java.sql.ResultSet;
import java.text.Format;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.br.ape.conexao.Conexao;
import com.br.ape.entities.Cliente;
import com.br.view.CadastroCliente;


public class ClienteDAO {
	
	private final Conexao con = new Conexao();
	private String msgExecucao;
	public static String nomeTemp; 
	public static int qntCd;
	public static int tempCd = 0;
	public boolean contagemCompleted;
	

	//CONTAR USUARIO
	public int contarCliente(){
		try {
			String sql = "SELECT * FROM CLIENTE";
			con.conectar();
			ResultSet rs = con.executarConsulta(sql);
			while (rs.next()) {
				
				qntCd = ((Number)rs.getObject(1)).intValue();
				rs.close();
				rs = null;
				con.desconectar();
				return qntCd;
			}
		}catch(Exception e) {
			
		}
		return 0;
	}
	public List<Cliente> buscas(String p, String tp){
		List<Cliente> clienteList = new ArrayList<>();
		Cliente cliente;
		
		try {
			String sql = null;
			if(tp.equals("NAME")) {
				sql ="SELECT * FROM CLIENTE WHERE NM_CLIENTE LIKE '"+p+"%'";
			}else if(tp.equals("UR")) {
				sql ="SELECT * FROM CLIENTE WHERE UR_CLIENTE LIKE '"+p+"%'";
			}
			
			con.conectar();
			ResultSet rs = con.executarConsulta(sql);
			//contarCliente();
			while (rs.next()){
				
				cliente = new Cliente();
				//PREPARANDO O ALIMENTO PARA SER INSERIDO NA LISTA
				cliente.setId(rs.getInt(1));
				cliente.setName(rs.getString(2));
				cliente.setDesc(rs.getString(3));	
				cliente.setPais(rs.getString(4));
				cliente.setUr(rs.getString(5));
				cliente.setQntProjetos(rs.getInt(6));
				cliente.setEmail(rs.getString(7));
				cliente.setNumero(rs.getString(8));
				cliente.setLucro(rs.getInt(9));
				cliente.setContrato(rs.getString(10));
				//POPULANDO LISTA DE ALIMENTOS...
				clienteList.add(cliente);
			}
			rs.close();
			rs = null;
			con.desconectar();	
		}catch(Exception e) {
			con.desconectar();
			System.out.print("Error List: "+ e);
		}
		return clienteList;
	}
	public List<Cliente> findAll(){
		List<Cliente> clienteList = new ArrayList<>();
		Cliente cliente;
		
		try {
			String sql = "SELECT * FROM CLIENTE ORDER BY CD_CLIENTE ASC";
			con.conectar();
			ResultSet rs = con.executarConsulta(sql);
			//contarCliente();
			while (rs.next()){
				
				cliente = new Cliente();
				//PREPARANDO O ALIMENTO PARA SER INSERIDO NA LISTA
				cliente.setId(rs.getInt(1));
				cliente.setName(rs.getString(2));
				cliente.setDesc(rs.getString(3));	
				cliente.setPais(rs.getString(4));
				cliente.setUr(rs.getString(5));
				cliente.setQntProjetos(rs.getInt(6));
				cliente.setEmail(rs.getString(7));
				cliente.setNumero(rs.getString(8));
				cliente.setLucro(rs.getInt(9));
				cliente.setContrato(rs.getString(10));
				//POPULANDO LISTA DE ALIMENTOS...
				clienteList.add(cliente);
			}
			rs.close();
			rs = null;
			con.desconectar();
			System.out.println("------------------------------");		
		}catch(Exception e) {
			con.desconectar();
			System.out.print("Error List: "+ e);
		}
		return clienteList;
	}
	//DELETAR USUARIO
	public String delete(Integer codigo) {
		String sql = "DELETE FROM playerTable WHERE id_player = "+ codigo;
		con.executarAtualizacao(sql);
		msgExecucao = "Exlclus�o"+ con.getMensagem();
		
		return msgExecucao;
	}
	
	public boolean createCliente(Cliente cliente) {
		try {
			
			
			String a = "INSERT INTO CLIENTE(CD_CLIENTE, NM_CLIENTE, DS_CLIENTE,  PS_CLIENTE, UR_CLIENTE, NR_CLIENTE, EM_CLIENTE, DT_CLIENTE)"
						+ "VALUES(seq_cli.nextval,'" + cliente.getName()
						+ "', '"+ cliente.getDesc()
						+ "', '"+ cliente.getPais()
						+"','"+cliente.getUr()
						+"','"+cliente.getNumero()
						+"','"+cliente.getEmail()
						+ "', '"+ cliente.getContrato()
						+ "')";	
			
			System.out.println(a);
			if(con.executarAtualizacao(a) != 0) {
				return true;
			}else {
				return false;
			}
			
			
				
		}catch(Exception e) {
			
			return false;
		}
		
		
	}
		
	
	public String update(Cliente cliente) {
		String sql = "UPDATE playerTable SET nm_player = '"
				+ cliente.getName().toUpperCase() + "', "+"posX = '"
				+ cliente.getLucro() + "' WHERE id_player ="+ cliente.getId();
		con.executarAtualizacao(sql);
		msgExecucao = "Atualiza��o "+ con.getMensagem();
		return msgExecucao;
				
	}
	public boolean loginCliente(String nome) {
		contarCliente();
		try {
			for(int i = 1; i < qntCd; i++) {
				System.out.println(i);
				String sql = "SELECT * FROM playerTable WHERE id_player = "+i;
				con.conectar();
				ResultSet rs = con.executarConsulta(sql);
				while (rs.next()) {
					if(nome.equals(rs.getObject(2))) {
						
						rs.close();
						rs = null;
						con.desconectar();
						return true;
					}
							
					con.desconectar();

				}
				
			}
			
			return false;
			
			
		}catch(Exception e) {
			System.out.print("SENHA OU NOME ERRADO: ");
			con.desconectar();
		}
			
			
			
		
		return false;
		
		
	}
	
		

}

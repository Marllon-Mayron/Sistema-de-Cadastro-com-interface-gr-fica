package com.br.ape.conexao;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

public class Conexao {
	//VARIAVEIS GLOBAIS
	private Connection con;
	private Statement s;
	//DADOS DE CONEXAO
	
	//ENCERE�O DO BANCO:
	private final String enderecoFisicoBanco = "jdbc:oracle:thin:@localhost:1521:";
	//NOME DO BANCO
	private final String banco = "xe";
	private final String usuario = "marllon";
	private final String senha = "M@rllon3455";
	private String mensagem;
	
	//METODO RESPONSAVEL POR ABRIR CONEX�O COM BANCO DE DADOS...
	public void conectar() {
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			System.out.println(url);
			con = DriverManager.getConnection(url,usuario,senha);
			if(con !=null) {
	
			}
			
		}catch(Exception e) {
			System.out.println("Erro conectar: "+ e.getMessage());
		}
	}
	//METODO RESPONSAVEL POR FECHAR CONEX�O COM O  BANCO DE DADOS...
	public void desconectar() {
		if(con != null) {
			try {
				if(s != null) {
					s.close();
					s = null;
				}
				con.close();
				//System.out.println("CONEX�O FECHADA...");
			}catch (Exception e) {
				//EM CASO DE ERRO
				System.out.println("Error desconectar : "+ e);
			}
		}
	}
	//METODO UTILIZADO PARA EXECUTAR ATUALIZA��ES: ATUALIZAR DELETAR INCLUIR.
	
	public int executarAtualizacao(String sql) {
		mensagem = "Sucesso na execu��o";
		try {
			conectar();
			if(s == null) {
				s = con.createStatement();
			}
			//EXECUTANDO SQL...
			int rs = s.executeUpdate(sql);
			//System.out.println(mensagem);
			desconectar();
			return rs;
		}catch (Exception e) {
			//EM CASO DE ERRO
			desconectar();
			mensagem = "Erro atualizar:" + e;
			System.out.println(mensagem);
		}
		return 0;
		
	}
	//METODO PARA EXECUTAR UMA CONSULTA PASSANDO UMA QUERY
	public ResultSet executarConsulta(String sql) {
		mensagem = "Sucesso na execu��o";
		try {
			if(s == null) {
				s = con.createStatement();
			}
			//System.out.println("Executando SQL de consulta");
			//ARMAZENA O RESULTADO DA CONSULTA
			ResultSet rs = s.executeQuery(sql);
			return rs;
		}catch(Exception e) {
			mensagem = "Erro executar:" + e;
			System.out.println(mensagem);
		}
		return null;

	}
	public String getMensagem() {
		return mensagem;
	}
	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}
	

}

package com.br.view;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.EventQueue;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import com.br.ape.bean.ClienteBean;
import com.br.ape.bean.SiteBean;
import com.br.ape.entities.Site;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.Font;

public class CadastroSite extends JFrame {

	private JPanel contentPane;
	private JTextField txt_link;
	private JTextField txt_desc;
	private JTextField txt_valor;
	private JTextField txt_mes;
	private JTextField txt_data_inicio;
	private JTextField txt_data_conclusao;
	ClienteBean cBean = new ClienteBean();
	private JTextField txt_pesquisa;
	private JTextField txt_cd_cliente;
	private JTextField txt_name;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroSite frame = new CadastroSite();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CadastroSite() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 600, 346);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		JPanel panel = new JPanel();
		contentPane.add(panel);
		txt_link = new JTextField();
		txt_link.setBounds(319, 53, 245, 20);
		txt_link.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Link: ");
		lblNewLabel.setBounds(278, 57, 42, 14);
		
		List list_cliente = new List();
		list_cliente.setBounds(66, 32, 169, 183);
		list_cliente.setEnabled(false);
		
		List list_cd = new List();
		list_cd.setBounds(21, 32, 39, 183);
		
		txt_desc = new JTextField();
		txt_desc.setBounds(433, 78, 131, 20);
		txt_desc.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Desc:");
		lblNewLabel_1.setBounds(392, 81, 35, 14);
		
		txt_valor = new JTextField();
		txt_valor.setBounds(319, 78, 63, 20);
		txt_valor.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Valor:");
		lblNewLabel_2.setBounds(278, 82, 42, 14);
		
		txt_mes = new JTextField();
		txt_mes.setBounds(519, 110, 45, 20);
		txt_mes.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("M\u00EAs:");
		lblNewLabel_3.setBounds(481, 113, 28, 14);
		
		txt_data_inicio = new JTextField();
		txt_data_inicio.setBounds(319, 110, 45, 20);
		txt_data_inicio.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Dt In:");
		lblNewLabel_4.setBounds(278, 107, 28, 14);
		
		txt_data_conclusao = new JTextField();
		txt_data_conclusao.setBounds(426, 110, 45, 20);
		txt_data_conclusao.setColumns(10);
		
		Label label = new Label("Dt Co:");
		label.setBounds(380, 108, 39, 22);
		
		txt_pesquisa = new JTextField();
		txt_pesquisa.setBounds(86, 270, 86, 20);
		txt_pesquisa.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Procufar:");
		lblNewLabel_5.setBounds(31, 273, 45, 14);
		
		JRadioButton rdbtn_find_cd = new JRadioButton("C\u00F3digo");
		rdbtn_find_cd.setBounds(21, 221, 78, 23);
		rdbtn_find_cd.setSelected(true);
		
		JRadioButton rdbtn_find_name = new JRadioButton("Nome");
		rdbtn_find_name.setBounds(113, 221, 59, 23);
		
		JRadioButton rdbtn_find_uf = new JRadioButton("uf");
		rdbtn_find_uf.setBounds(197, 221, 57, 23);
		
		Button button_load_values = new Button("Carregar");
		button_load_values.setBounds(178, 268, 57, 22);
		button_load_values.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				list_cd.removeAll();
				list_cliente.removeAll();
				int idStart = 0;
				if(rdbtn_find_cd.isSelected()) {
					if(txt_pesquisa.getText().equals("")) {
						idStart = 0;
					}else {
						idStart = Integer.parseInt(txt_pesquisa.getText())-1;	
					}
						
					for(int i = idStart; i < cBean.listarTodos().size(); i++) {
						int  n = cBean.listarTodos().get(i).getId();
						String id = String.valueOf(n);
						list_cd.add(id);
						list_cliente.add(cBean.listarTodos().get(i).getName());
					}
				}else if(rdbtn_find_name.isSelected()) {
					for(int i = idStart; i < cBean.listarTodos().size(); i++) {
						int  n = cBean.buscar(txt_pesquisa.getText(), "NAME").get(i).getId();
						String id = String.valueOf(n);
						list_cd.add(id);
						list_cliente.add(cBean.buscar(txt_pesquisa.getText(), "NAME").get(i).getName());
					}
				}else if(rdbtn_find_uf.isSelected()){
					for(int i = idStart; i < cBean.listarTodos().size(); i++) {
						int  n = cBean.buscar(txt_pesquisa.getText(), "uf").get(i).getId();
						String id = String.valueOf(n);
						list_cd.add(id);
						list_cliente.add(cBean.buscar(txt_pesquisa.getText(), "uf").get(i).getName());
					}
				}
				
				
				
				
			}
		});
		
		JButton btn_cadastrar = new JButton("Cadastrar");
		btn_cadastrar.setBounds(380, 269, 81, 23);
		btn_cadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Site site = new Site();
				SiteBean sbean = new SiteBean();
				site.setIdCliente(Integer.parseInt(txt_cd_cliente.getText()));
				site.setNome(txt_name.getText());
				site.setLink(txt_link.getText());
				site.setDesc(txt_desc.getText());
				site.setValor(txt_valor.getText());
				site.setMes(txt_mes.getText());
				site.setDtInicio(txt_data_inicio.getText());
				site.setDtFim(txt_data_conclusao.getText());
				
				sbean.criar(site);
				
			}
		});
		
		JLabel lblNewLabel_6 = new JLabel("Pesquisa R\u00E1pida");
		lblNewLabel_6.setBounds(82, 11, 78, 14);
		
		JLabel lblNewLabel_7 = new JLabel("C\u00F3digo de cliente respons\u00E1vel:");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_7.setBounds(319, 165, 203, 33);
		
		txt_cd_cliente = new JTextField();
		txt_cd_cliente.setBounds(392, 221, 54, 33);
		txt_cd_cliente.setColumns(10);
		
		txt_name = new JTextField();
		txt_name.setBounds(319, 29, 245, 20);
		txt_name.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("Nome:");
		lblNewLabel_8.setBounds(278, 32, 45, 14);
		panel.setLayout(null);
		panel.add(lblNewLabel_6);
		panel.add(lblNewLabel_8);
		panel.add(txt_name);
		panel.add(list_cd);
		panel.add(list_cliente);
		panel.add(rdbtn_find_cd);
		panel.add(rdbtn_find_name);
		panel.add(rdbtn_find_uf);
		panel.add(lblNewLabel);
		panel.add(lblNewLabel_2);
		panel.add(lblNewLabel_4);
		panel.add(txt_link);
		panel.add(txt_valor);
		panel.add(lblNewLabel_1);
		panel.add(txt_desc);
		panel.add(txt_data_inicio);
		panel.add(label);
		panel.add(txt_data_conclusao);
		panel.add(lblNewLabel_3);
		panel.add(txt_mes);
		panel.add(lblNewLabel_7);
		panel.add(txt_cd_cliente);
		panel.add(lblNewLabel_5);
		panel.add(txt_pesquisa);
		panel.add(button_load_values);
		panel.add(btn_cadastrar);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setBounds(260, 150, 314, 137);
		panel.add(separator_1);
		
		JSeparator separator = new JSeparator();
		separator.setOrientation(SwingConstants.VERTICAL);
		separator.setBounds(260, 11, 314, 276);
		panel.add(separator);
	}
}

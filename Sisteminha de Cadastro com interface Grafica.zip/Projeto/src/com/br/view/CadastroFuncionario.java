package com.br.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import com.br.ape.entities.Funcionario;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JToggleButton;
import javax.swing.JRadioButton;
import java.awt.Label;
import java.awt.ScrollPane;
import javax.swing.JButton;

public class CadastroFuncionario extends JFrame {

	private JPanel contentPane;
	private JTextField txt_name;
	private JTextField txt_cargo;
	private JTextField txt_setor;
	private JTextField txt_email;
	private JLabel lblNewLabel_3;
	private JTextField txt_numero;
	private JLabel lblNewLabel_4;
	private JTextField txt_desc;
	private JLabel lblNewLabel_5;
	private JRadioButton rdbtn_sexo_f;
	private ScrollPane scrollPane;
	private JLabel lblNewLabel_6;
	private JButton btn_cadastrar;
	private JTextField txt_cpf;
	private JLabel lblNewLabel_7;
	private JTextField txt_ur;
	private JLabel lblNewLabel_8;
	private JTextField txt_data;
	private JLabel lblNewLabel_9;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroFuncionario frame = new CadastroFuncionario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CadastroFuncionario() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 550, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Cadastrar Funcionario", TitledBorder.CENTER, TitledBorder.TOP, null, null));
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		txt_name = new JTextField();
		txt_name.setBounds(50, 25, 201, 30);
		panel.add(txt_name);
		txt_name.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Nome:");
		lblNewLabel.setBounds(10, 25, 46, 30);
		panel.add(lblNewLabel);
		
		txt_cargo = new JTextField();
		txt_cargo.setBounds(325, 66, 189, 30);
		panel.add(txt_cargo);
		txt_cargo.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Cargo:");
		lblNewLabel_1.setBounds(269, 74, 46, 14);
		panel.add(lblNewLabel_1);
		
		txt_setor = new JTextField();
		txt_setor.setBounds(50, 66, 201, 30);
		panel.add(txt_setor);
		txt_setor.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Setor:");
		lblNewLabel_2.setBounds(10, 72, 46, 19);
		panel.add(lblNewLabel_2);
		
		txt_email = new JTextField();
		txt_email.setBounds(325, 25, 189, 30);
		panel.add(txt_email);
		txt_email.setColumns(10);
		
		JLabel label = new JLabel("New label");
		label.setBounds(269, 82, 34, -10);
		panel.add(label);
		
		lblNewLabel_3 = new JLabel("Email:");
		lblNewLabel_3.setBounds(269, 25, 46, 30);
		panel.add(lblNewLabel_3);
		
		txt_numero = new JTextField();
		txt_numero.setBounds(60, 107, 110, 30);
		panel.add(txt_numero);
		txt_numero.setColumns(10);
		
		lblNewLabel_4 = new JLabel("Numero:");
		lblNewLabel_4.setBounds(10, 111, 58, 22);
		panel.add(lblNewLabel_4);
		
		txt_desc = new JTextField();
		txt_desc.setBounds(50, 148, 218, 30);
		panel.add(txt_desc);
		txt_desc.setColumns(10);
		
		lblNewLabel_5 = new JLabel("Desc:");
		lblNewLabel_5.setBounds(10, 156, 46, 14);
		panel.add(lblNewLabel_5);
		scrollPane = new ScrollPane();
		scrollPane.setBounds(231, 107, 84, 30);
		JRadioButton rdbtn_sexo_m = new JRadioButton("M");
		rdbtn_sexo_m.setBounds(238, 111, 39, 23);
		panel.add(rdbtn_sexo_m);
		rdbtn_sexo_m.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rdbtn_sexo_f.setSelected(false);
								
			}
			
			
		});
		
		rdbtn_sexo_f = new JRadioButton("F");
		rdbtn_sexo_f.setBounds(278, 111, 34, 23);
		panel.add(rdbtn_sexo_f);
		
		
		panel.add(scrollPane);
		
		lblNewLabel_6 = new JLabel("G\u00EAnero:");
		lblNewLabel_6.setBounds(180, 111, 58, 22);
		panel.add(lblNewLabel_6);
		
		btn_cadastrar = new JButton("Cadastrar");
		btn_cadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Funcionario func = new Funcionario();
				func.setNome(txt_name.getText());
				func.setCargo(txt_cargo.getText());
				func.setCpf(txt_cpf.getText());
				func.setDataAdmissao(txt_data.getText());
				func.setEmail(txt_email.getText());
				func.setNumero(txt_numero.getText());
				func.setUr(txt_ur.getText());
				func.setSetor(txt_setor.getText());
				func.setDesc(txt_desc.getText());
				if(rdbtn_sexo_f.isSelected()) {
					func.setSexo('F');
				}else {
					func.setSexo('M');
				}
			}
		});
		btn_cadastrar.setBounds(425, 217, 89, 23);
		panel.add(btn_cadastrar);
		
		txt_cpf = new JTextField();
		txt_cpf.setBounds(366, 107, 148, 30);
		panel.add(txt_cpf);
		txt_cpf.setColumns(10);
		
		lblNewLabel_7 = new JLabel("CPF:");
		lblNewLabel_7.setBounds(325, 115, 46, 14);
		panel.add(lblNewLabel_7);
		
		txt_ur = new JTextField();
		txt_ur.setBounds(456, 148, 58, 30);
		panel.add(txt_ur);
		txt_ur.setColumns(10);
		
		lblNewLabel_8 = new JLabel("UR:");
		lblNewLabel_8.setBounds(416, 156, 46, 14);
		panel.add(lblNewLabel_8);
		
		txt_data = new JTextField();
		txt_data.setBounds(325, 148, 84, 30);
		panel.add(txt_data);
		txt_data.setColumns(10);
		
		lblNewLabel_9 = new JLabel("Dt Ad:");
		lblNewLabel_9.setBounds(278, 156, 46, 14);
		panel.add(lblNewLabel_9);
		rdbtn_sexo_f.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				rdbtn_sexo_m.setSelected(false);
								
			}
			
			
		});
		
	}
}

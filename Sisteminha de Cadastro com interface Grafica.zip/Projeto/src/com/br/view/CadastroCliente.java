package com.br.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.br.ape.bean.ClienteBean;
import com.br.ape.entities.*;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.awt.event.ActionEvent;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JSeparator;
import javax.swing.JTabbedPane;


public class CadastroCliente extends JFrame {

	private JPanel contentPane;
	private JTextField txt_name_cliente;
	private JTextField txt_estado;
	private JPanel panel;
	public ClienteBean clienteBean = new ClienteBean();
	public Cliente cliente = new Cliente();
	private JTextField txt_desc;
	private JLabel lblNewLabel_1;
	private JTextField txt_numero;
	private JTextField txt_email;
	Locale l = new Locale("pt","BR");

	NumberFormat nf = NumberFormat.getInstance(l);
	private JLabel lbl_date;
	private JTextField txt_data;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;
	private JLabel lblNewLabel_5;
	private JTextField txt_pais;
	private JLabel lblNewLabel_6;
	private JLabel lblNewLabel_7;
	private JSeparator separator;
	

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the frame.
	 */
	public CadastroCliente() {
		setAlwaysOnTop(true);
		setTitle("APE PROGRAMA");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setSize(500, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btn_cad_cliente = new JButton("CADASTRAR");
		btn_cad_cliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
					
				SimpleDateFormat formato = new SimpleDateFormat("yyyy/MM/dd"); 
				
				
				if(e.getSource() == btn_cad_cliente) {
					cliente.setName(txt_name_cliente.getText());
					cliente.setDesc(txt_desc.getText());
					cliente.setPais(txt_pais.getText());
					cliente.setUr(txt_estado.getText());
					cliente.setNumero(txt_numero.getText());
					cliente.setEmail(txt_email.getText());
					cliente.setContrato(txt_data.getText());
					showMessage(clienteBean.criar(cliente));
				}
				
				
				
				
				
				
				
			}
		});
		btn_cad_cliente.setBounds(347, 427, 108, 23);
		contentPane.add(btn_cad_cliente);
		
		JLabel lblNewLabel = new JLabel("REGISTRAR NOVO CLIENTE");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Arial", Font.PLAIN, 16));
		lblNewLabel.setBounds(98, 18, 285, 14);
		contentPane.add(lblNewLabel);
		
		panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(30, 43, 425, 373);
		contentPane.add(panel);
		panel.setLayout(null);
		
		txt_name_cliente = new JTextField();
		txt_name_cliente.setBounds(51, 11, 364, 23);
		panel.add(txt_name_cliente);
		txt_name_cliente.setColumns(10);
		
		txt_estado = new JTextField();
		txt_estado.setBounds(182, 166, 45, 23);
		panel.add(txt_estado);
		txt_estado.setColumns(10);
		
		txt_desc = new JTextField();
		txt_desc.setBounds(51, 44, 151, 22);
		panel.add(txt_desc);
		txt_desc.setColumns(10);
		
		lblNewLabel_1 = new JLabel("Inforam\u00E7\u00F5es Pessoais");
		lblNewLabel_1.setBounds(159, 119, 131, 22);
		panel.add(lblNewLabel_1);
		
		txt_numero = new JTextField();
		txt_numero.setBounds(295, 166, 120, 23);
		panel.add(txt_numero);
		txt_numero.setColumns(10);
		
		txt_email = new JTextField();
		txt_email.setBounds(59, 208, 356, 22);
		panel.add(txt_email);
		txt_email.setColumns(10);
		
		lbl_date = new JLabel("Data: Ex(dd/mm/yyyy)");
		lbl_date.setHorizontalAlignment(SwingConstants.TRAILING);
		lbl_date.setBounds(212, 45, 120, 21);
		panel.add(lbl_date);
		
		txt_data = new JTextField();
		txt_data.setBounds(345, 45, 70, 20);
		panel.add(txt_data);
		txt_data.setColumns(10);
		
		lblNewLabel_2 = new JLabel("Nome:");
		lblNewLabel_2.setBounds(10, 11, 45, 23);
		panel.add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("Desc:");
		lblNewLabel_3.setBounds(10, 44, 34, 22);
		panel.add(lblNewLabel_3);
		
		lblNewLabel_4 = new JLabel("UF:");
		lblNewLabel_4.setBounds(155, 166, 23, 23);
		panel.add(lblNewLabel_4);
		
		lblNewLabel_5 = new JLabel("Numero:");
		lblNewLabel_5.setBounds(237, 166, 59, 23);
		panel.add(lblNewLabel_5);
		
		txt_pais = new JTextField();
		txt_pais.setBounds(49, 166, 96, 20);
		panel.add(txt_pais);
		txt_pais.setColumns(10);
		
		lblNewLabel_6 = new JLabel("Pa\u00EDs:");
		lblNewLabel_6.setBounds(10, 165, 34, 23);
		panel.add(lblNewLabel_6);
		
		lblNewLabel_7 = new JLabel("E-mail:");
		lblNewLabel_7.setBounds(10, 208, 45, 23);
		panel.add(lblNewLabel_7);
		
		separator = new JSeparator();
		separator.setBounds(10, 149, 405, 213);
		panel.add(separator);
	}
	public double converte(String arg) throws ParseException{
		//obtem um NumberFormat para o Locale default (BR)
		NumberFormat nf = NumberFormat.getNumberInstance();
		
		//converte um n�mero com v�rgulas ex: 2,56 para double
		double number = nf.parse(arg).doubleValue();
		return number;
	}
	public void showMessage(boolean r) {
		if(r == false) {
			JOptionPane.showMessageDialog(contentPane, "             FRACASSO!!");
		}else {
			JOptionPane.showMessageDialog(contentPane, "             SUCESSO!!");
		}
		
	}
}
